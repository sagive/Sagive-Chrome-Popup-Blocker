Sagive POP Up Blocker
=============

This small chrome addon was born out of necessity. I actually worked out of my home for a while always had a movie or a TV series on.

POPUPS! that's the problem. i tried many addons but none worked...

All i really needed is a way to save some websites in a close automatically list - so... this is what i did!

How it works
-------
You save a list of "bad URLs" (in base mode - ie: example.com). 

If a tab or a window opens up (for any reason) with a url that exists in the list you created it would:

0. The session in that tab / window would be canceled
0. That tab / window would be closed automatically


Why its great?
-------
becouse its a small addon that nobody know and thus nobody would block it or search for. Or.. simply put - it works!